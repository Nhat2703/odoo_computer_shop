{
    'name': 'Computer Shop Management',
    'version': '1.0',
    'category': 'Sales',
    'summary': 'Quản lý linh kiện máy tính, hóa đơn, công nợ, dashboard doanh thu chi phí',
    'depends': ['base', 'sale', 'stock', 'account'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/product_views.xml',
        'views/invoice_views.xml',
        'views/dashboard_views.xml',
        'data/email_template.xml',
    ],
    'installable': True,
    'application': True,
}
