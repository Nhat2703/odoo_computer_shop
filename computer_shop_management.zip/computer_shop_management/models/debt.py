from odoo import models, fields

class CustomerDebt(models.Model):
    _name = 'customer.debt'
    _description = 'Công nợ khách hàng'

    customer_id = fields.Many2one('res.partner', string='Khách hàng')
    amount_due = fields.Monetary(string='Số tiền còn nợ')
    due_date = fields.Date(string='Ngày đến hạn')
