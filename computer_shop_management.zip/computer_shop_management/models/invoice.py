from odoo import models, fields

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    debt_amount = fields.Monetary(string='Công nợ')
