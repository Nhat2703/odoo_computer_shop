from odoo import models, fields

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    cost_price = fields.Float(string='Giá nhập')
    profit_margin_percent = fields.Float(string='% Lợi nhuận')
